const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));

// Define the 'sass' task to compile SASS into CSS
gulp.task('sass', function () {
  return gulp.src('src/sass/**/*.scss')  // Path to your SASS files
    .pipe(sass().on('error', sass.logError))  // Compile SASS
    .pipe(gulp.dest('src/css'));  // Output compiled CSS
});

// Define the 'watch' task to watch SASS files for changes
gulp.task('watch', function () {
  gulp.watch('src/sass/**/*.scss', gulp.series('sass'));  // Watch SASS files and run the 'sass' task on change
});

// Default task to run both 'sass' and 'watch'
gulp.task('default', gulp.series('sass', 'watch'));