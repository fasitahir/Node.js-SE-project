const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const dotenv = require('dotenv');
dotenv.config();

const employees = [];

// Middleware to parse JSON
app.use(bodyParser.json());

// Serve static files (CSS, HTML, JS)
app.use(express.static('src'));

// Add an employee
function addEmployee(name, email) {
  if (name && email) {
    employees.push({ name, email });
    return { success: true, message: 'Employee added successfully', employees };
  } else {
    return { success: false, message: 'Both name and email are required' };
  }
}

// API route for adding employee
app.post('/addEmployee', (req, res) => {
  const { name, email } = req.body;
  const result = addEmployee(name, email);
  if (result.success) {
    res.status(200).send(result);
  } else {
    res.status(400).send(result);
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Exporting addEmployee for testing
module.exports = { addEmployee, employees };
