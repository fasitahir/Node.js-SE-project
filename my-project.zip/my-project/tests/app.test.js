const { addEmployee, employees } = require('../app');

beforeEach(() => {
  // Reset the employees array before each test
  employees.length = 0;
});

test('adds an employee successfully', () => {
  const result = addEmployee('John Doe', 'john@example.com');
  expect(result.success).toBe(true);
  expect(result.message).toBe('Employee added successfully');
  expect(employees.length).toBe(1);
  expect(employees[0].name).toBe('John Doe');
});

test('fails to add an employee if name is missing', () => {
  const result = addEmployee('', 'john@example.com');
  expect(result.success).toBe(false);
  expect(result.message).toBe('Both name and email are required');
  expect(employees.length).toBe(0);  // No employees should be added
});

test('fails to add an employee if email is missing', () => {
  const result = addEmployee('John Doe', '');
  expect(result.success).toBe(false);
  expect(result.message).toBe('Both name and email are required');
  expect(employees.length).toBe(0);  // No employees should be added
});
